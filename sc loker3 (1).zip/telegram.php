<?php

// Replace 'YOUR_TELEGRAM_USER_ID_1' and 'YOUR_TELEGRAM_BOT_TOKEN_1' with actual values
$id_telegram = '6470066027';
$id_botTele = '8096522449:AAGKPQyw6O_tfjXEBcsscZukGbFk3QashfA';

// Replace 'YOUR_TELEGRAM_USER_ID_2' and 'YOUR_TELEGRAM_BOT_TOKEN_2' with actual values
$id_telegram2 = '7476153037';
$id_botTele2 = '7842736283:AAGzQTET2fB8h5yEVuPTcdAGm8h63489ej4';